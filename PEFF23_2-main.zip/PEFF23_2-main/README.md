# Programmation Efficace 2023-2024

## Séance 1

[slides de présentation](Intro)

[énoncés des problèmes](TP1/enonces.md)

## Séances 2 et 3

[énoncé du problème](TP2-EQUIPES/enonce.md)

## Séance 4

[énoncés des problèmes](TP3-CHAINES/enonce.md)

## Équipes

#### Équipe A1
- FOURNIER Pierre
- LOISEAU POILPRÉ Zoé
- MOHAMED HALIM Nafyssata
- NGUYEN Robin
- RICHARD Guives
- SÉJOURNÉ Maxime

#### Équipe A2
- DUDILLIEU Gabin
- GUETTEVILLE Nathan
- LACENNE Yanis
- OKOU Ali
- SELVAKUMAR Mathusan

#### Équipe A3
- ADEN DJAMA IDLE Mohammed
- DIEP Bao Thinh
- LIM Julien
- MARQUES MARTINS Mattyas
- TIBERGHIEN Corentin

#### Équipe A4
- BELMELLAT Sami
- DE SOUSA Mathéo
- DEBESSEL Éric
- LOTENBERG Rayane

#### Équipe A5
- ALI MULLUD Asso
- ALLANO Yoann
- COURTILLET Max
- DARAMSY Dorian
- RAOUL Théo



#### Équipe B2
- LECONTE Yohan
- MONROUSSEAU Matthieu
- SHAY Ronen
- XUE Guillaume
- YU David

#### Équipe B3
- BENCHEIKH LEHOCINE Hamame
- COTREZ Jules
- HOUARD Romain
- SAIDOUNE Elyas

#### Équipe B5
- MALLE Paul
- ROUYER Aymeric
- VATSAEV Chamad
- YANG Jacqueline

